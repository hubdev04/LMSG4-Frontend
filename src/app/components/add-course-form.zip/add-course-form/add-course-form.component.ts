import { Component } from '@angular/core';
import { AddCourseService } from '../../services/add-course.service';
import { Course } from '../../services/course-mentor.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-add-course-form',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterOutlet,RouterLink,RouterModule],
  templateUrl: './add-course-form.component.html',
  styleUrls: ['./add-course-form.component.css']
})
export class AddCourseFormComponent {
  courseForm: any  = {
    title: '',
    category: '',
    duration: 0,
    description: '',
  };

  categories = ['Beginner', 'Intermediate', 'Advanced'];

  constructor(private addCourseService: AddCourseService) {}

  onSubmit() {
    if (this.courseForm.title) {
      console.log('Submitting course data:', this.courseForm);  // Log the form data before submission
      this.addCourseService.addCourse(this.courseForm).subscribe({
        next: (response) => {
          console.log('Response from server:', response);  // Log the response from the server
          if (response.success) {
            console.log('Course added successfully', response);
            alert('Course added successfully');
            this.resetForm();
          } else {
            this.resetForm();
            console.log("Error:", response.message);
          }
        },
        error: (err) => {
          console.error("Error during course submission:", err);
        }
      });
    }
  }

  resetForm() {
    this.courseForm = {
      title: '',
      category: '',
      duration: 0,
      description: ''
    };
  }
}
