import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { QueryService } from '../../query.service';
@Component({
  selector: 'app-course',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterOutlet,RouterLink,RouterModule],
  templateUrl: './course.component.html',
  styleUrl: './course.component.css'
})
export class CourseComponent {
  course = {
    title: 'Course Title',
    description: 'This is a detailed description of the course.',
    image: 'path/to/image.jpg'
  };

  // You can initialize any other data or services here
  constructor(private router: Router) {}

  navigateTo(route: string) {
    this.router.navigate([route]);
  }
}
